"""
MCP Client wrapper for the Smart Trip Planning Assistant
=========================================================

What is this file?
-------------------
This is the **MCP client** side. It knows how to:
  1. Start the MCP server (mcp_server/server.py) as a subprocess.
  2. Speak the MCP protocol to it (over stdio).
  3. Call a named tool with arguments and get a plain Python dict back.

Why a background thread + event loop?
--------------------------------------
The official `mcp` Python SDK is async (built on asyncio: `async def`,
`await`). But this project's agents (weather_agent, destination_agent,
etc.) are plain, synchronous functions called from a synchronous
Streamlit app and a synchronous LangGraph graph.

Rather than rewriting the entire agent pipeline to be async, we do this
once, here:
  - Start ONE background thread.
  - Run an asyncio event loop inside that thread.
  - Connect to the MCP server once, inside that loop, and keep the
    connection open (so we're not paying subprocess-startup cost on
    every single tool call).
  - Expose a normal, blocking `call_tool(name, arguments)` method that any
    ordinary synchronous code can call — it internally hands the async
    work to the background loop and waits for the result.

This is a common, beginner-friendly pattern for bridging "async library"
and "sync application code". You should not need to touch this file to
add new tools — just add them to mcp_server/server.py and call them via
mcp_client/tools.py.
"""

import asyncio
import atexit
import os
import sys
import threading
from contextlib import AsyncExitStack

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SERVER_SCRIPT = os.path.join(PROJECT_ROOT, "mcp_server", "server.py")


class MCPClientWrapper:
    """Keeps one long-lived MCP connection alive on a background thread
    and exposes a synchronous `call_tool()` method."""

    def __init__(self, command: str, args: list[str], cwd: str | None = None):
        self.command = command
        self.args = args
        self.cwd = cwd

        self._loop: asyncio.AbstractEventLoop | None = None
        self._session: ClientSession | None = None
        self._exit_stack: AsyncExitStack | None = None
        self._ready = threading.Event()
        self._start_error: Exception | None = None

        self._thread = threading.Thread(target=self._run_loop, daemon=True)
        self._thread.start()

        # Wait for the background thread to finish connecting (or fail).
        if not self._ready.wait(timeout=30):
            raise RuntimeError("Timed out starting the MCP server.")
        if self._start_error:
            raise self._start_error

    # ── background thread machinery ─────────────────────────────────────
    def _run_loop(self):
        self._loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self._loop)
        try:
            self._loop.run_until_complete(self._connect())
        except Exception as e:  # surfaced to the main thread via _ready
            self._start_error = e
        finally:
            self._ready.set()
        self._loop.run_forever()

    async def _connect(self):
        self._exit_stack = AsyncExitStack()
        params = StdioServerParameters(
            command=self.command,
            args=self.args,
            cwd=self.cwd,
        )
        read, write = await self._exit_stack.enter_async_context(stdio_client(params))
        self._session = await self._exit_stack.enter_async_context(ClientSession(read, write))
        await self._session.initialize()

    # ── public sync API ─────────────────────────────────────────────────
    def call_tool(self, name: str, arguments: dict) -> dict:
        """Call an MCP tool by name and return its result as a plain dict.
        Safe to call from normal synchronous code / any thread."""
        if self._start_error:
            return {"error": f"MCP server failed to start: {self._start_error}"}

        future = asyncio.run_coroutine_threadsafe(self._call_tool_async(name, arguments), self._loop)
        try:
            return future.result(timeout=60)
        except Exception as e:
            return {"error": f"MCP tool call '{name}' failed: {e}"}

    async def _call_tool_async(self, name: str, arguments: dict) -> dict:
        import json

        result = await self._session.call_tool(name, arguments)

        if getattr(result, "isError", False):
            text = result.content[0].text if result.content else "Unknown MCP tool error"
            return {"error": text}

        if not result.content:
            return {}

        # FastMCP tools that return a dict are serialized as a JSON text block.
        text = result.content[0].text
        try:
            return json.loads(text)
        except Exception:
            return {"raw": text}

    def close(self):
        if not self._loop or not self._loop.is_running():
            return
        try:
            fut = asyncio.run_coroutine_threadsafe(self._exit_stack.aclose(), self._loop)
            fut.result(timeout=10)
        except Exception:
            pass
        self._loop.call_soon_threadsafe(self._loop.stop)


# ── module-level singleton ───────────────────────────────────────────────
# We only want ONE MCP server subprocess running for the whole app, so we
# lazily create the client once and reuse it everywhere.
_client_instance: MCPClientWrapper | None = None
_client_lock = threading.Lock()


def get_client() -> MCPClientWrapper:
    global _client_instance
    if _client_instance is None:
        with _client_lock:
            if _client_instance is None:  # double-checked locking
                _client_instance = MCPClientWrapper(
                    command=sys.executable,
                    args=[SERVER_SCRIPT],
                    cwd=PROJECT_ROOT,
                )
                atexit.register(_client_instance.close)
    return _client_instance
