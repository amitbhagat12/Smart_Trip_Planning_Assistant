"""
Drop-in replacements for the old direct service calls, now routed through MCP.

Before (direct import, in-process call):
    from services.weather_service import get_weather
    from services.serper_service import search_serper

After (this file — goes through the MCP client -> MCP server -> same
underlying service function):
    from mcp_client.tools import get_weather, search_serper

The function names, arguments, and return shapes are UNCHANGED on purpose,
so the agent code (weather_agent.py, destination_agent.py, transport_agent.py,
budget_agent.py) only needed a one-line import change — no other logic
had to move.
"""

from mcp_client.client import get_client


def get_weather(city: str) -> dict:
    """Same shape as services.weather_service.get_weather, but called
    over MCP instead of imported directly."""
    return get_client().call_tool("get_weather", {"city": city})


def search_serper(query: str, num_results: int = 5) -> dict:
    """Same shape as services.serper_service.search_serper, but called
    over MCP instead of imported directly."""
    return get_client().call_tool("web_search", {"query": query, "num_results": num_results})
