"""
MCP Server for the Smart Trip Planning Assistant
=================================================

What is this file?
-------------------
This is an **MCP server**. In plain English: it's a small standalone
program that exposes a fixed set of "tools" (plain Python functions) over
a standard protocol (Model Context Protocol / MCP), so that ANY MCP-aware
client — this project's Streamlit app, Claude Desktop, another agent
framework, etc. — can call them the same way, without needing to import
this project's Python code directly.

Why did we add this?
---------------------
Before MCP, `agents/weather_agent.py` and friends imported
`services/weather_service.py` and `services/serper_service.py` directly
and called their functions in-process. That works, but it tightly couples
the agents to this exact codebase.

With MCP, we instead:
  1. Wrap the same underlying logic (services/weather_service.py and
     services/serper_service.py — UNCHANGED) as MCP "tools".
  2. Run this file as a separate process (the "MCP server").
  3. Have the agents talk to it through an MCP "client" instead of
     importing the service modules directly (see mcp_client/).

This is the standard MCP pattern: server = exposes tools, client = calls
tools. Nothing about the actual weather/search logic changes — we're only
adding a standard protocol layer on top of it.

How it runs
-----------
This server uses "stdio transport", the simplest MCP transport: the
client starts this script as a subprocess and talks to it over
stdin/stdout. You never run this file manually — mcp_client/client.py
launches it automatically the first time a tool is needed.
"""

import os
import sys

# Make sure "services" (and the rest of the project) is importable no
# matter which directory this script is launched from, since MCP clients
# start this file as a subprocess.
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from mcp.server.fastmcp import FastMCP  # noqa: E402

from services.weather_service import get_weather as _get_weather  # noqa: E402
from services.serper_service import search_serper as _search_serper  # noqa: E402

# The name below is what shows up when a client lists connected MCP
# servers (e.g. in Claude Desktop's settings).
mcp = FastMCP("smart-trip-planner-tools")


@mcp.tool()
def get_weather(city: str) -> dict:
    """
    Get the current live weather for a city using OpenWeatherMap.

    Args:
        city: City name, e.g. "Goa" or "Paris".

    Returns:
        A dict with temp_celsius, description, humidity — or an
        "error" key if the lookup failed.
    """
    return _get_weather(city)


@mcp.tool()
def web_search(query: str, num_results: int = 5) -> dict:
    """
    Run a live Google web search (via the Serper API) and return the raw
    results (answer box + organic results).

    Args:
        query: The search query text.
        num_results: How many organic results to request (default 5).

    Returns:
        The raw Serper JSON response as a dict, or an "error" key if the
        search failed.
    """
    return _search_serper(query, num_results)


if __name__ == "__main__":
    # Default transport is stdio, which is exactly what mcp_client/client.py
    # expects (it launches this script and talks over stdin/stdout).
    mcp.run()
